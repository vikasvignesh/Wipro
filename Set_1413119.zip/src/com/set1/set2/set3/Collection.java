package com.set1.set2.set3;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;


public class Collection {
	public static void main(String[] args) {
		TreeSet <Integer> al=new TreeSet<Integer>();
		al.add(1);
		al.add(3);
		al.add(2);
	TreeSet<Integer> re=(TreeSet<Integer>) al.descendingSet();
		System.out.println("Reverce order:  "+re);
		System.out.println("Iterator:");
		Iterator <Integer>i=al.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
		}
		System.out.println("Enter the element to search");
		Scanner in=new Scanner(System.in);
		int s=in.nextInt();
		int c=0;
		for(int a:al){
			if(a==s){
				System.out.println("exist");}
			else{
				c++;}
			if(c==al.size())
				System.out.println("Not Exist");
					}
	}

}
