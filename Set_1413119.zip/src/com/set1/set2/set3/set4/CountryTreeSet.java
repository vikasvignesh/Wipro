package com.set1.set2.set3.set4;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
public class CountryTreeSet {HashSet <String> H1=new HashSet<String>();
String Country;
HashSet <String> saveCountryNam(String CountryName){
	
	H1.add(CountryName);
	return H1;
}
void getCountr(String Country){
	int flag=0;
	Iterator <String> i=H1.iterator();
	while(i.hasNext()){
		String tempcon=i.next();
		if(tempcon.equals(Country))
		System.out.println(Country);
		else
			flag++;
	}
	if(flag==H1.size())
		System.out.println("Not exist");
	
}
public static void main(String[] args) {
Scanner obj=new Scanner(System.in);
CountryTreeSet o=new CountryTreeSet();
o.saveCountryNam("india");
o.saveCountryNam("singa");
o.saveCountryNam("uk");
System.out.println("Enter the country");
String s=obj.next();
o.getCountr(s.toLowerCase());
}
}
