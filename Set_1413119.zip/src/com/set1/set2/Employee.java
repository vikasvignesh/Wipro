package com.set1.set2;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class Employee {
	public static void main(String[] args) {
		int n;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter no of employee");
		n=s.nextInt();
		HashSet<String> h1=new HashSet<String>();
		System.out.println("Enter employ name");
		for(int i=0;i<n;i++){
			h1.add(s.next());
		}
	Iterator <String> i=h1.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
		}
	}

}
