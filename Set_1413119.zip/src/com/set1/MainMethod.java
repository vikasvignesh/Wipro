package com.set1;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class MainMethod {
	HashSet <String> H1=new HashSet<String>();
	String Country;
	HashSet <String> saveCountryName(String CountryName){
		
		H1.add(CountryName);
		return H1;
	}
	void getCountry(String Country){
		int flag=0;
		Iterator <String> i=H1.iterator();
		while(i.hasNext()){
			String tempcon=i.next();
			if(tempcon.contains(Country))
			System.out.println(Country);
			else
				flag++;
		}
		if(flag==H1.size())
			System.out.println("Not exist");
		
	}
public static void main(String[] args) {
	Scanner obj=new Scanner(System.in);
	MainMethod o=new MainMethod();
	o.saveCountryName("india");
	o.saveCountryName("singa");
	o.saveCountryName("uk");
	System.out.println("Enter the country");
	String s=obj.next();
	o.getCountry(s.toLowerCase());
}
}
