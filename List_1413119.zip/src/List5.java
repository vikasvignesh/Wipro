import java.util.*;
class Employee{
	int id;
	String name;
	String address;
	int sal=0;
	Employee(int id,String name,String address,int sal){
		this.id=id;
		this.name=name;
		this.address=address;
		this.sal=sal;
	}
}
public class List5 {
	public static void main(String[] args) {
	ArrayList <Employee> emp=new ArrayList<Employee>();
	emp.add(new Employee(1,"vikas","salem",1000));
	emp.add(new Employee(2,"perkey","chennai",1000));
	int id=0;
	Scanner in=new Scanner(System.in);
	System.out.println("Enter id");
	id=in.nextInt();
	Iterator <Employee> i=emp.iterator();
	while(i.hasNext()){
		Employee e=i.next();
		if(e.id==id){
			System.out.println(e.name+" "+e.address+" "+e.sal);
		}
		
	}

}
}