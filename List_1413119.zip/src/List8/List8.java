package List8;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

class Employee{
	int id;
	String name;
	Employee(int id,String name){
		this.id=id;
		this.name=name;
	}
	void display(){
		System.out.println(id);
		System.out.println(name);
	}
}
public class List8 {
	public static void main(String[] args) {
		Employee emp1=new Employee(1, "vikas");
		Employee emp2=new Employee(2, "trickcse");
		Employee emp3=new Employee(3, "perkey");
		Vector<Employee> v=new Vector<Employee>();
		v.add(emp1);
		v.add(emp2);
		v.add(emp3);
		System.out.println("Using Iterator");
		Iterator <Employee> i=v.iterator();
		while(i.hasNext()){
			i.next().display();
		}
		System.out.println();
		System.out.println("Using Enumuration");
		Enumeration<Employee> e1=Collections.enumeration(v);
		while(e1.hasMoreElements()){
			e1.nextElement().display();
		}
	}

}
