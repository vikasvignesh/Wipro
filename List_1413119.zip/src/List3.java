import java.util.*;
public class List3 {
	static void printAll(ArrayList<String> a){
		Iterator i=a.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
		}
	}
public static void main(String[] args) {
	ArrayList<String> s=new ArrayList<String>();
	s.add("Employee1");
	s.add("Employee2");
	s.add("Employee3");
	s.add("Employee4");
	printAll(s);
}
}
