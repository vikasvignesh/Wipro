package List7;

import java.util.*;

import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;
public class List7{
	Vector<Integer> A1=new Vector<Integer>();
	
	Vector<Integer> saveEvenNumbers(int N){
		for(int i=1;i<N;i++){
			if(i%2==0)
			A1.add(i);
		}
		return A1;
	}
	Vector<Integer> printEvenNumbers(Vector A1){
		Vector <Integer> A2=new Vector<Integer>();
		Iterator <Integer> i=A1.iterator();
		while(i.hasNext()){
			A2.add(i.next()*2);
		}
		return A2;
	}
	 int printEvenNumber(int N){
		if(A1.contains(N)){
			return N;
		}else{
			return 0;
		}
	 }
	public static void main(String[] args) {
		List7 o=new List7();
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the number");
		int N=in.nextInt();
		Vector <Integer> aobj=new Vector<Integer>();
		aobj=o.saveEvenNumbers(N);
		Vector <Integer> aobj1=new Vector<Integer>();
		aobj1=o.printEvenNumbers(aobj);
		System.out.println(aobj);
		System.out.println(aobj1);
		System.out.println("Enter element to search");
		int m=in.nextInt();
		System.out.println(o.printEvenNumber(m));
		
		
	}

}
