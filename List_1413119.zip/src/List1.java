import java.util.*;

import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;
public class List1 {
	ArrayList<Integer> A1=new ArrayList<Integer>();
	
	ArrayList<Integer> saveEvenNumbers(int N){
		for(int i=1;i<N;i++){
			if(i%2==0)
			A1.add(i);
		}
		return A1;
	}
	ArrayList<Integer> printEvenNumbers(ArrayList<Integer> aobj){
		ArrayList<Integer> A2=new ArrayList<Integer>();
		Iterator <Integer> i=aobj.iterator();
		while(i.hasNext()){
			A2.add(i.next()*2);
		}
		return A2;
	}
	 int printEvenNumber(int N){
		if(A1.contains(N)){
			return N;
		}else{
			return 0;
		}
	 }
	public static void main(String[] args) {
		List1 o=new List1();
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the number");
		int N=in.nextInt();
		ArrayList <Integer> aobj=new ArrayList<Integer>();
		aobj=o.saveEvenNumbers(N);
		ArrayList <Integer> aobj1=new ArrayList<Integer>();
		aobj1=o.printEvenNumbers(aobj);
		System.out.println(aobj);
		System.out.println(aobj1);
		System.out.println("Enter element to search");
		int m=in.nextInt();
		System.out.println("element is "+o.printEvenNumber(m));
		
		
	}

}