package handson2;

import java.util.ArrayList;

public class EmployeeDB {
	private ArrayList<Employee> list=new ArrayList<Employee>();
	boolean addEmployee(Employee e) {
		return list.add(e);
	}
	boolean deleteEmployee(int eCode) {
		return list.remove(eCode) != null;
	}
	String showPaySlip(int eCode) {
		return list.get(eCode).name;
	}
	Employee[] listAll() {
		Employee[] e=new Employee[list.size()];
		return list.toArray(e);
	}
}
