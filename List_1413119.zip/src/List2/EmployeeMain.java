package handson2;

public class EmployeeMain {
  public static void main(String[] args) {
	EmployeeDB db=new EmployeeDB();
	db.addEmployee(new Employee("arun",21));
	db.addEmployee(new Employee("gopal", 22));
	db.addEmployee(new Employee("gokul", 26));
	Employee employee[]=db.listAll();
	for(Employee e:employee) {
		System.out.println(e.name +" "+e.age);
	}
	System.out.println(db.showPaySlip(1));
	if(db.deleteEmployee(1)) {
		employee=db.listAll();
		for(Employee e:employee) {
			System.out.println(e.name +" "+e.age);
		}
	}
}
}
