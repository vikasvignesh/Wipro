package handson2;

public class Employee {
      String name;
      int age;
      Employee(String name,int age){
    	  this.name=name;
    	  this.age=age;
      }
}
