package List6;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class List6{
	LinkedList<Integer> A1=new LinkedList<Integer>();
	
	LinkedList<Integer> saveEvenNumbers(int N){
		for(int i=1;i<N;i++){
			if(i%2==0)
			A1.add(i);
		}
		return A1;
	}
	LinkedList<Integer> printEvenNumbers(LinkedList A1){
		LinkedList <Integer> A2=new LinkedList<Integer>();
		Iterator <Integer> i=A1.iterator();
		while(i.hasNext()){
			A2.add(i.next()*2);
		}
		return A2;
	}
	 int printEvenNumber(int N){
		if(A1.contains(N)){
			return N;
		}else{
			return 0;
		}
	 }
	public static void main(String[] args) {
		List6 o=new List6();
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the number");
		int N=in.nextInt();
		LinkedList<Integer> aobj=new LinkedList<Integer>();
		aobj=o.saveEvenNumbers(N);
		LinkedList <Integer> aobj1=new LinkedList<Integer>();
		aobj1=o.printEvenNumbers(aobj);
		System.out.println(aobj);
		System.out.println(aobj1);
		System.out.println("Enter element to search");
		int m=in.nextInt();
		System.out.println("element is "+o.printEvenNumber(m));
		
		
	}

}
