import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

class AllDataType{
	int a;
	double b;
	double c;
	AllDataType(int a,double b,double c){
		this.a=a;
		this.b=b;
		this.c=c;
		}
}
public class List4 {
public static void main(String[] args) {
	Scanner s1=new Scanner(System.in);
	System.out.println("Enter integer");
	int x=s1.nextInt();
	System.out.println("Enter float");
	double y=s1.nextDouble();
	System.out.println("Enter double");
	double z=s1.nextDouble();
	AllDataType o=new AllDataType(x, y, z);
	ArrayList <AllDataType> ar=new ArrayList<AllDataType>();
	ar.add(o);
	Iterator<AllDataType> i=ar.iterator();
	while(i.hasNext()){
		AllDataType s=i.next();
		System.out.println(s.a+" "+s.b+" "+s.c);
		//System.out.println(i.next().a);
	}
	
}
}
