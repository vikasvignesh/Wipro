package com.map2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class ExistOrNot {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		HashMap<Integer,String> h=new HashMap<Integer,String>();
		int key;
		String value;
		h.put(1, "vikas");
		h.put(2, "Pareek");
		h.put(3, "Amy");
		System.out.println("Enter the key");
		key=s.nextInt();
		for(Entry<Integer, String> k:h.entrySet()){
			int tempkey=k.getKey();
			if(key==tempkey)
				System.out.println("Exist");
		}
			System.out.println("Enter the string");
			value=s.next();
			for(Entry<Integer, String> k:h.entrySet()){
				String tempvalue=k.getValue();
				if(value.equals(tempvalue))
					System.out.println("Exist");
			}
					
		
			System.out.println("Iterate The Value");
			Iterator i= h.entrySet().iterator();
			while(i.hasNext()){
				Map.Entry o=(Entry) i.next();
				System.out.println(o.getKey()+" "+o.getValue());
				
			}
	}

}
