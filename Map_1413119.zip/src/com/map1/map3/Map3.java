package com.map1.map3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.text.html.parser.Entity;

public class Map3 {
public static void main(String[] args) {
	HashMap<String, String>l=new HashMap<String,String>(); 
	l.put("India", "delhi");
	l.put("uk", "london");
	Iterator i=l.entrySet().iterator();
	while(i.hasNext()){
		Map.Entry ob=(Entry) i.next();
		System.out.println(ob.getKey()+" "+ob.getValue());
	}
}
}
