package com.map1.map2.map3.map4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import javax.swing.text.html.parser.Entity;

public class PhoneBook {
public static void main(String[] args) {
	HashMap<String,String> h=new HashMap<String,String>();
	h.put("vikas","8438282948");
	h.put("Saravana","94432102938");
	h.put("sanjai", "908263547321");
	System.out.println("Enter name to find number");
	Scanner in=new Scanner(System.in);
	String name=in.next();
	Iterator i=h.entrySet().iterator();
	while(i.hasNext()){
Map.Entry m=(Entry) i.next();
if(m.getKey().equals(name)){
	System.out.println(m.getValue());
}

}
}
}
