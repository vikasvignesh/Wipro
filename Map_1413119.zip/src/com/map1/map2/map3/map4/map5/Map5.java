package com.map1.map2.map3.map4.map5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.map1.MainMap;

public class Map5 {
	String CountryMap;
	TreeMap <String,String> M1=new TreeMap<String,String>();
	static TreeMap <String,String> M2=new TreeMap<String,String>();
	static ArrayList<String> A1=new ArrayList<String>();
	TreeMap <String,String> saveCountryCapital(String CountryName,String Capital){
	 M1.put(CountryName,Capital);
	 return M1;
 }
	String getCapital(String countryName){
		for(Entry<String, String> M:M1.entrySet()){
			String findk=M.getKey();
			String finfv=M.getValue();
			if(findk.equals(countryName))
				return finfv;
			
		}
		return null;
	}
	String getCountry(String capitalName){
		for(Entry<String, String> M:M1.entrySet()){
			String findk=M.getKey();
			String finfv=M.getValue();
			if(finfv.equals(capitalName))
				return findk;
		}
		return null;
	}
	TreeMap<String, String> swap(){
		Iterator<Map.Entry<String,String>>i=M1.entrySet().iterator();
		while(i.hasNext()){
			Entry<String, String> con=i.next();
			M2.put(con.getValue(),con.getKey());
		}
		return M2;
	}
	ArrayList<String> toStore(){
		for(Entry<String, String> k:M1.entrySet()){
			String cont=k.getKey();
			A1.add(cont);
		}
		return A1;
	}
	public static void main(String[] args) {
		Map5 mp=new Map5();
		mp.saveCountryCapital("India", "Delhi");
		mp.saveCountryCapital("Uk", "London");
		System.out.println("TO display capital");
		System.out.println(mp.getCapital("Uk"));
		System.out.println("To display country");
		System.out.println(mp.getCountry("London"));
		System.out.println("Copy to Other MapSet:");
		mp.swap();
		System.out.println(M2);
		System.out.println("copy country to ArraySet:");
		mp.toStore();
		System.out.println(A1);
	}

}
